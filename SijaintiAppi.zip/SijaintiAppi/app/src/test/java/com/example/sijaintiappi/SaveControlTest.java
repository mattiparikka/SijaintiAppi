package com.example.sijaintiappi;

import org.junit.Test;

public class SaveControlTest {

    @Test
    public void testAddLine(){
        //
    }

}

/*public class CalcTest {

    @Test
    public void testBasic() {
        assertEquals(2, Calc.compute("1+1"));
    }*/