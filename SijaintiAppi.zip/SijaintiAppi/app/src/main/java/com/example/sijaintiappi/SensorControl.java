package com.example.sijaintiappi;


import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;


/**
 * Luokka sensoritietojen käsittelyyn
 */
class SensorControl implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private String currentAcc = "";
    private String[] current = new String[3];

    SensorControl(Context context){
        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
    }


    /**
     * Aloitetaan valitun sensorin kuuntelu. Tässä tapauksessa accelerometer
     */
    void startAccSensor(){
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL); //luokan täytyy implementoida on sensorjuttu. Huomioitava jos siirretään.
    }


    /**
     * Lopetetaan sensorin kuuntelu. Tässä tapauksessa accelerometer
     */
    void stopAccSensor(){
        sensorManager.unregisterListener(this, accelerometer);
    }


    /**
     * @return palautetaan nykyinen sensoritieto merkkijonona
     */
    String getAcc(){
        return this.currentAcc;
    }


    /**
     * @return palautetaan sensoritietoja sisältävä taulukko
     */
    String[] getCurrentAcc(){
        return this.current;
    }


    /**
     * Päivitetään sensoritietoja sisältävä taulukko ja viimeisin sensoritieto merkkojonoksi aina, kun uusi tieto on saatavilla
     * @param event valitun sensorin tapahtuma
     */
    @Override
    public void onSensorChanged(SensorEvent event) {
        String x = current[0] = String.format("%.3f", event.values[0]);
        String y = current[1] = String.format("%.3f", event.values[1]);
        String z = current[2] = String.format("%.3f", event.values[2]);
        currentAcc = x + ',' + y + ',' + z;

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

}
