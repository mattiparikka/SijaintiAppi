package com.example.sijaintiappi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.lifecycle.LifecycleObserver;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;



public class MainActivity extends AppCompatActivity implements LifecycleObserver/*implements SensorEventListener*/ {

    private SaveControl saveControl;
    private SensorControl sensorControl;
    private LocationControl locationControl;

    public static final int REQUEST_CODE = 1000;
    private TextView txt_loc;
    private TextView txt_acc;
    private TextView txt_accuracy;
    private TextView txt_speed;
    private TextView txt_altitude;
    private TextView txt_bearing;
    private Button btn_start, btn_stop;
    private boolean btn_start_enabled = true;

    private boolean isSaved = false;
    // private boolean requestingLocUpdates = false; ei käytössä, ks. onResume koodin kommentointi.

    private Handler timerHandler = new Handler();
    private Runnable timerRunnable = new Runnable() {

        @Override
        public void run() {
            long timeStamp = System.currentTimeMillis();

            //Tämä muunnos mielestäni tarpeeton, koska olisi parempi tallentaa tuo aika tiedostoon suoraan millisekunteina. Muunnos kuitenkin helpottaa
            //tiedoston lukua, jotta voidaan varmistua päivitysten tapahtuvan haluttujen ajanjaksojen välein tai mahdollisimman lähellä sitä.
            //Enemmän operaatioita välissä toki aiheuttaa pientä viivettä, eikä pävitysväliä voi varmasti taata.
            SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss.SSS");
            Calendar k = Calendar.getInstance();
            k.setTimeInMillis(timeStamp);

            if (locationControl.getLocData()[0] == null) timerHandler.postDelayed(this, 100); // jos ei vielä ole saatu mitään päivitettävää, mennään yksi sykli eteenpäin
            else {
                txt_loc.setText(locationControl.getLocData()[0] + " / " + locationControl.getLocData()[1]);
                txt_acc.setText(sensorControl.getCurrentAcc()[0] + " / " + sensorControl.getCurrentAcc()[1] + " / " + sensorControl.getCurrentAcc()[2]);

                txt_bearing.setText(locationControl.getLocData()[2]);
                txt_altitude.setText(locationControl.getLocData()[3]);
                txt_speed.setText(locationControl.getLocData()[4]);
                txt_accuracy.setText(locationControl.getLocData()[5]);

                // Lisätään tallennettavien tietojen taulukkoon vain ja aina, jos start-nappi on painettuna.
                if (!btn_start_enabled) saveControl.checkAdd(formatter.format(k.getTime()) + ',' + locationControl.getCurrentLoc() + ',' + sensorControl.getAcc());
                timerHandler.postDelayed(this, 100);
            }
        }
    };


    @Override
    public void onPause() {
        super.onPause();
        stopUpdatesAndSave();
        timerHandler.removeCallbacks(timerRunnable);
    }


    @Override
    public void onResume(){
        super.onResume();
        // Koska määrittelyissä ei sanottu tarkemmin, niin valitsin sijainti- ja kiihtyvyystietojen päivittyvän aina,
        // kun sovellus on käyttäjälle näkyvissä riippumatta siitä, onko tallennusnappia painettu.
        // Mikäli päivitysten haluttaisiin näkyvän vain silloin, kun tallennus tapahtuu, tulisi tänne if-lause, joka tarkistaa onko
        // käyttäjä aloittanut tietojen pyynnön. Tämä tieto kuskattaisiin taas bundlessa mukana eri syklien välillä.
        checkPermissions();
    }


    // MIhin tätä tarvitaan???
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // requestCode tässä tapauksessa tarpeeton, koska ei tule switch-case rakennetta, koska ei ole muita oikeuksien pyyntöjä sijainnin lisäksi.
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            locationControl = new LocationControl(getApplicationContext()); // luodaan sijaintiin liittyvät toiminnot vasta, kun on varmistuttu sijaintitietojen oikeuksista.
            startUpdates();
        }
        else{
            // Oikeuksia ei ole, pidetään huolta, että start-nappi on edelleen aktiivinen, näytetään toast ja palataan pois aloittamatta sijaintipäivityksiä.
            btn_start_enabled = true;
            enableButtons();
            Toast toast = Toast.makeText(this, "Please enable location to get data", Toast.LENGTH_LONG);
            toast.show();
        }
    }


    /**
     * Asetetaan näkymät
     */
    private void setTextViews(){
        txt_loc = findViewById(R.id.locTextView);
        txt_acc = findViewById(R.id.accTextView);
        txt_accuracy = findViewById(R.id.accuracyTextView);
        txt_speed = findViewById(R.id.spdTextView);
        txt_altitude = findViewById(R.id.altTextView);
        txt_bearing = findViewById(R.id.bearTextView);

        btn_start = findViewById(R.id.startBtn);
        btn_stop = findViewById(R.id.stopBtn);
    }

    @Override
    protected void onSaveInstanceState(Bundle data){
        super.onSaveInstanceState(data);
        data.putBoolean("startButtonEnabled", btn_start_enabled);
        data.putBoolean("isSaved", saveControl.isSaved()); // Jos poistutaan käynnissä olevasta ohjelmasta, tallennetaan bundleen tieto siitä, onko kaikki tiedot tallennettu
        // Tämä pitäisi tulla onPause jälkeen, koska muuten tallennusta ei koskaan kutsuta ja tila on väärin. Onko tässä mahdollisesti ongelma?
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initialization
        setTextViews();

        // Tuodaan bundlesta arvot, mikäli tullaan onCreateen tallennetusta tilasta. startButton edellyttää, että nappi on luotu ensin eli setTextViews ennen tätä.
        // isSaved käyttö tallennuksen tarkistamiseen edellyttää, että saveControl luodaan tämän jälkeen, jotta voidaan viedä sinne tieto tallennuksen mielekkyydestä.
        if (savedInstanceState != null) {
            this.btn_start_enabled = savedInstanceState.getBoolean("startButtonEnabled");
            this.isSaved = savedInstanceState.getBoolean("isSaved");
        }

        saveControl = new SaveControl(getApplicationContext(), isSaved);
        sensorControl = new SensorControl(getApplicationContext());

        checkPermissions();
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION))
        {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
        }
        else
        {
            btn_start.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    btn_start_enabled = false;
                    //startUpdates(); ei käynnistetä sensoreita tässä, koska ne ovat jo käynnissä oikeuksien tarkistuksen jälkeen jos ne voidaan käynnistää.
                    // tämä on suunnittelupäätös, jossa tietoja näytetään käyttäjälle, vaikka tallennusta ei ole aloitettu
                    enableButtons();

                }
            });

            btn_stop.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    btn_start_enabled = true;
                    enableButtons();
                }
            });
        }
    }


    /**
     * Vaihdetaan näppäinten tila sen perusteella, missä tialssa ollaan oltu.
     * Näppäinten tilaa pidetään yllä boolean-arvolla, joka tuodaan savedInstanceState bundlessa mukana,
     * jos sovellus käynnistyy esimerkiksi orientaation muutoksen myötä uudestaan.
     */
    private void enableButtons(){
        if (btn_start_enabled) {
            btn_start.setEnabled(true);
            btn_stop.setEnabled(false);
        }
        else {
            btn_start.setEnabled(false);
            btn_stop.setEnabled(true);
        }
    }


    /**
     * Oikeuksien tarkistus ja sensoreiden sammutus pausen tai ohjelman sammutuksen ajaksi
     */
    //@OnLifecycleEvent(Lifecycle.Event.ON_PAUSE)
    private void stopUpdatesAndSave(){
        //checkPermissions(); Ei liene tarvetta tarkistaa oikeuksia kun suljetaan sensoreita??
        locationControl.removeLocUpdates();
        sensorControl.stopAccSensor();
        saveControl.saveToCSV();
        enableButtons();
    }


    /**
     * Oikeuksien tarkistus ja sensoreiden käynnistys. Ajastimen käynnistys
     */
    //@OnLifecycleEvent(Lifecycle.Event.ON_START)
    private void startUpdates(){
        locationControl.requestLocUpdates();
        sensorControl.startAccSensor();
        // timer tänne, koska requestLocationUpdates aloitaa kuuntelijan ja onLocationResult päivittää currentloc-kenttää, kun uusi saveControl on saatavilla
        timerHandler.postDelayed(timerRunnable,0);
        enableButtons();
    }


    /**
     * Yhdistetään oikeuksien tarkistus yhteen metodiin.
     */
    private void checkPermissions(){
        if (ActivityCompat.checkSelfPermission(MainActivity.this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(MainActivity.this,Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQUEST_CODE);
            return;
        }
        locationControl = new LocationControl(getApplicationContext()); // luodaan sijaintiin liittyvät toiminnot vasta, kun on varmistuttu sijaintitietojen oikeuksista.
        startUpdates();
    }

}
