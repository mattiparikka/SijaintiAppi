package com.example.sijaintiappi;


import android.content.Context;
import android.location.Location;
import android.os.Looper;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

/**
 * Luokka sijaintitietojen käsittelyyn
 */
class LocationControl {

    private FusedLocationProviderClient fusedLocationProviderClient;
    private LocationRequest locationRequest;
    private LocationCallback locationCallback;
    private String[] locData = new String[6];


    LocationControl(Context context){
        buildLocationRequest();
        buildLocationCallBack();
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(context);
    }


    /**
     * @return Sijaintitiedot merkkijonona
     */
    String getCurrentLoc(){
        return locData[0]
                + ',' + locData[1]
                + ',' + locData[2]
                + ',' + locData[3]
                + ',' + locData[4]
                + ',' + locData[5];
    }


    /**
     * @return palautetaan sijaintitietoja sisältävä taulukko
     */
    String[] getLocData(){
        return this.locData;
    }


    /**
     * Luodaan locationcallback ja asetetaan sijaintitiedot taulukkoon aina, kun ne päivittyvät.
     */
    private void buildLocationCallBack() {
        // private String lat,lon,bea,alt,spd,accuracy; Voisi luoda tässäkin ilman attribuutteja, mutta silloin joka kerta luodaan uudet 6 merkkijonoa. Nyt vain sijoitetaan.
        locationCallback = new LocationCallback()
        {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) return;
                for(Location loc: locationResult.getLocations()) {
                    locData[0] = String.valueOf(loc.getLatitude());
                    locData[1] = String.valueOf(loc.getLongitude());
                    locData[2] = String.valueOf(loc.getBearing());
                    locData[3] = String.valueOf(loc.getAltitude());
                    locData[4] = String.valueOf(loc.getSpeed());
                    locData[5] = String.valueOf(loc.getAccuracy());
                }
            }
        };
    }


    /**
     * Dokumentaation mukaan tarvitsee Priority High accuracy ja setInterval 5sec, jotta voi käyttää access fine location.
     * Oletetaan, että virrankäyttö ei ole ongelma ja halutaan korkea tarkkuus.
     */
    private void buildLocationRequest() {
        locationRequest = new LocationRequest();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(5000);
        locationRequest.setFastestInterval(3000);
        locationRequest.setSmallestDisplacement(10);
    }


    /**
     * Aloitetaan sijaintitietojen pyytäminen ja silmukka
     */
    void requestLocUpdates(){
        fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());
    }


    /**
     * Pysäytetään sijaintitietojen päivittäminen
     */
    void removeLocUpdates(){
        fusedLocationProviderClient.removeLocationUpdates(locationCallback);
    }


}
