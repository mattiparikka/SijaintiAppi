package com.example.sijaintiappi;


import android.content.Context;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * Luokka, joka huolehtii kaiken tallennukseen liittyvän.
 */
class SaveControl {


    private Context context;
    private ArrayList<String> lines = new ArrayList<>();
    private boolean changed;
    private String prevLine = ",,";


    SaveControl(Context context, boolean state){
        this.context = context;
        this.changed = state;
    }


    /**
     * Tyhjennetään taulukko, kun painetaan nauhoituksen keskeytystä. Vältetään saman datan kirjoitus moneen kertaan.
     * Tiedostoon tallennuksen metodi huolehtii, että uusi taulukko kirjoitetaan edellisen datan perään. Eri kutsulla
     * hoidetaan datan poisto tiedostosta, jos tarpeen.
     */
    private void resetArray(){
        lines.clear();
        changed = true;
    }


    /**
     * @return palautetaan tieto onko kaikki tiedossa ollut data tallennettu eli tarvitseeko tallentaa uudestaan.
     */
    boolean isSaved(){
        return this.changed;
    }


    /**
     * Lisätään taulukkoon valmis rivi
     * @param data taulukkoon lisättävä rivi
     */
    private void addLine(String data) {
        this.lines.add(data);
        changed = true;
    }


    /**
     * tarkistetaan onko nykyinen sijainti sama, kuin edellinen taulukon sijainti ja lisätään, jos ei ole
     * @param data nykyinen sijainti ja accelerometer
     * @return boolean
     */
    boolean checkAdd(String data){
        if (data.equals(",,") || data.equals("")) return false;
        if (data.equals(this.prevLine)) return false;
        prevLine = data;
        addLine(data);
        return true;
    }


    /**
     * Tallennetaan tiedostoon. Tarkistetaan ennen tallennusta onko tallentamattomia tietoja. Tarkistetaan ennen tallennusta onko tiedosto jo olemassa.
     */
    void saveToCSV (){
        if (!changed) return; // jos tila ei ole muuttunut, poistutaan tallentamatta
        String fActual = "locData.csv";

        //Tarkistetaan onko tiedosto jo laitteella, jotta vältetään uuden otsikkorivin luonti. Voisi myös lukea tiedostosta, mutta silloin pitäisi avata uusi inputStream ja onko
        //tämä tehokkaampi tapa tarkistaa?
        File check = new File(context.getFilesDir(), fActual);
        boolean fileExists = false;
        if (check.exists()) fileExists = true;

        try (FileOutputStream fos = context.openFileOutput(fActual, Context.MODE_APPEND); PrintWriter pw = new PrintWriter(fos)){
            if (!fileExists) pw.println(";;TIMESTAMP,LATITUDE,LONGITUDE,BEARING,ALTITUDE,SPEED,ACCURACY,X,Y,Z"); // jos tiedostoa ei ole, luodaan otsikkorivi ensin.

            for (int i = 0; i < lines.size(); i++){
                pw.println(lines.get(i));
            }
        } catch (FileNotFoundException ex) {
            Log.e("Tiedostoa ei löytynyt",ex.toString());
        } catch (IOException ex) {
            Log.e("Kirjoitus epäonnistui", ex.toString());
        }

        this.changed = false; //tallennuksen jälkeen ollaan tilassa, jossa ei kannata tallentaa uudestaan
        resetArray(); // kaikki taulukon tiedot on tallennettu, tyhjennetään taulukko, jotta seuraava tallennus ei tallenna uudestaan vanhoja tietoja.
    }





}
